#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>
#include "PruebasRogue.h"

void inicializarJugador(Jugador* j, int x, int y)
{
    j->x=x;
    j->y=y;
    j->hpMax=100;
    j->hp=100;
    j->nivel=1;
    j->exp=0;
    j->fuerza=10;
    j->cantItems=0;
    j->tieneArma=0;
    j->tieneArmadura=0;
    j->tieneAmuleto=0;
}

void revelarSala(Mapa* mapa, int f, int c)
{
    int i, j;
    Sala* sala=&mapa->salas[f][c];

    for(i=sala->y ; i<sala->y+sala->alto ; i++)
    {
        for(j=sala->x; j<sala->x+sala->ancho; j++) //me paro en la posicion (x,y) y genero la habitacion
        {
            mapa->visible[i][j]=1;
        }
    }
}

Jugador colocarJugador(Mapa* mapa)
{
    int i, j, flag=0, medioX, medioY;

    Jugador player;

    while(flag==0)
    {
        i=rand()%3;
        j=rand()%3;

        //buscamos las coordeanas de spawn del jugador (en el medio de la sala en este caso)
        medioX=mapa->salas[i][j].x + mapa->salas[i][j].ancho/2;
        medioY=mapa->salas[i][j].y + mapa->salas[i][j].alto/2;

        if(mapa->salas[i][j].existe==1 && mapa->grilla[medioY][medioX]!='>')
        {
            flag = 1; //si existe y no es la sala con la escalera
        }

    }

    revelarSala(mapa,i,j);

    inicializarJugador(&player,medioX,medioY);

    return player;

}

void siguienteNivel(Mapa* mapa, Jugador* player, char escalera)
{
    int flag=0, i=0, j;
    int medioX, medioY;

    //buscamos la posicion de la escalera de subida o bajada para ubicar al jugador ahi
    while(flag==0 && i<FIL_SALAS)
    {
        j=0;
        while(flag==0 && j<COL_SALAS)
        {
            if(mapa->salas[i][j].existe==1)
            {
                medioX=mapa->salas[i][j].x + mapa->salas[i][j].ancho/2;
                medioY=mapa->salas[i][j].y + mapa->salas[i][j].alto/2;

                if(mapa->grilla[medioY][medioX]==escalera)
                {
                    flag=1;
                }
            }
            j++;
        }
        i++;
    }

    //nueva posicion del jugador
    player->x=medioX;
    player->y=medioY;
}

void juego(Mapa** mapa, int pisos)
{
    char comando='0', destino, actual;
    int proximoX, proximoY, f, c, pisoActual=0;
    Mapa* mapActual=mapa[pisoActual];
    Jugador player=colocarJugador(mapActual);

    while(comando!='q' && player.hp>0 && player.tieneAmuleto==0)
    {
        mostrarMapa(mapActual, player, pisoActual);

        comando=getch();

        proximoX=player.x;
        proximoY=player.y;

        switch (comando)
        {
            case 'w': proximoY--; break;
            case 's': proximoY++; break;
            case 'a': proximoX--; break;
            case 'd': proximoX++; break;
            case 'W': proximoY--; break;
            case 'S': proximoY++; break;
            case 'A': proximoX--; break;
            case 'D': proximoX++; break;
        }
        destino=mapActual->grilla[proximoY][proximoX];

        if (destino=='.' || destino=='#' || destino=='+' || destino=='>' || destino=='<')
        {
            if (destino=='>')//si pisó la escalera, hacemos el cambio de piso
            {
                if(mapActual->enemigosVivos==0)
                {
                    printf("\nBajar al siguiente piso? Y = Bajar | N = Quedarse");
                    comando=getch();
                    if(comando=='y' || comando=='Y')
                    {
                        pisoActual++;
                        mapActual=mapa[pisoActual];
                        siguienteNivel(mapActual,&player,'<');
                    }
                    if(comando=='n' || comando=='N')
                    {
                        player.x=proximoX;
                        player.y=proximoY;
                        actual=mapActual->grilla[player.y][player.x];
                    }
                }
                else
                {
                    printf("\nUna especie de magia te impide bajar. Presiona cualquier tecla para avanzar");
                    getch();
                    player.x=proximoX;
                    player.y=proximoY;
                    actual=mapActual->grilla[player.y][player.x];
                }

            }
            else if (destino=='<')
            {
                printf("\nSubir al siguiente piso? Y = Subir | N = Quedarse");
                comando=getch();
                if(comando=='y' || comando=='Y')
                {
                    pisoActual--;
                    mapActual=mapa[pisoActual];
                    siguienteNivel(mapActual,&player,'>');
                }
                if(comando=='n' || comando=='N')
                {
                    player.x=proximoX;
                    player.y=proximoY;
                    actual=mapActual->grilla[player.y][player.x];
                }
            }
            else
            {
                f=player.y / ALTO_MAX_SALA;
                c=player.x / ANCHO_MAX_SALA;
                if(mapActual->salas[f][c].hayItem==0) colocarItem(mapActual,f,c,pisoActual);

                if (obtenerSimboloEnemigo(mapActual,proximoY,proximoX)!='\0')
                {
                    combate(mapActual,&player,f,c,pisoActual,pisos);
                }

                else if (obtenerSimboloItem(mapActual,proximoY,proximoX)!='\0')
                {
                    agarrarItem(mapActual,&player,f,c);
                }
                else
                {
                    player.x=proximoX;
                    player.y=proximoY;
                    //si no fue una escalera, item, o enemigo, entonces es un movimiento normal
                    actual=mapActual->grilla[player.y][player.x];

                    if (actual=='.') //si estoy en el suelo de una sala, la revelo
                    {
                        colocarEnemigo(mapActual,f,c,pisoActual);
                        moverEnemigo(mapActual,&player,f,c);
                    }
                    else if (actual=='#' || actual=='+') //si estoy en un pasillo o puerta, solo revelo donde estoy parado y el siguiente
                    {
                        if(mapActual->grilla[player.y+1][player.x]=='#' || mapActual->grilla[player.y+1][player.x]=='+')  mapActual->visible[player.y+1][player.x]=1;
                        if(mapActual->grilla[player.y][player.x+1]=='#' || mapActual->grilla[player.y][player.x+1]=='+')  mapActual->visible[player.y][player.x+1]=1;
                        if(mapActual->grilla[player.y-1][player.x]=='#' || mapActual->grilla[player.y-1][player.x]=='+')  mapActual->visible[player.y-1][player.x]=1;
                        if(mapActual->grilla[player.y][player.x-1]=='#' || mapActual->grilla[player.y][player.x-1]=='+')  mapActual->visible[player.y][player.x-1]=1;
                    }
                }
            }

            if(comando=='i' || comando== 'I')
            {
                mostrarInventario(&player);
            }
        }
    }
    if(player.hp<=0) printf("\nHAS MUERTO");
    if(player.tieneAmuleto==1) printf("\nHAS GANADO");
}

void terminarjuego(Mapa** vecMap, int pisos)
{
    for(int i=0; i<pisos; i++)
        {
            liberarMapa(vecMap[i]);
        }
        free(vecMap);
}
