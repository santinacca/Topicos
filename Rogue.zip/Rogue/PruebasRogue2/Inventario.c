#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include "PruebasRogue.h"

void colocarItem(Mapa* mapa, int f, int c, int piso)
{

    Item* i;
    int n;

    mapa->salas[f][c].hayItem=1;

    if ((rand() % 100) < 70)
    {
        do
        {
            i=&mapa->salas[f][c].item;
            i->x=mapa->salas[f][c].x + 1 + (rand() % (mapa->salas[f][c].ancho-2));
            i->y=mapa->salas[f][c].y + 1 + (rand() % (mapa->salas[f][c].alto-2));
            if(mapa->grilla[i->y][i->x]!='<' || mapa->grilla[i->y][i->x]!='>')
            {
                i->activo=1;

                n=rand() % 10;
                switch (n)
                {
                    case 0:i->simbolo='H';i->tipo=2 ;i->piso=0; i->cant=0;strcpy(i->nombre,"Pocion de vida"); i->valor=30 ; break;
                    case 1:i->simbolo='E';i->tipo=2 ;i->piso=0; i->cant=0;strcpy(i->nombre,"Pocion de experiencia"); i->valor=25 ; break;
                    case 2:i->simbolo='$';i->tipo=2 ;i->piso=0; i->cant=0;strcpy(i->nombre,"Oro"); i->valor=1 ; break;
                    case 3:i->simbolo='F';i->tipo=2 ;i->piso=0; i->cant=0;strcpy(i->nombre,"Pocion de fuerza"); i->valor=2 ; break;
                    case 4:i->simbolo='V';i->tipo=2 ;i->piso=0; i->cant=0;strcpy(i->nombre,"Pocion verde"); i->valor=20 ; break;
                    case 5:i->simbolo='L';i->tipo=0 ;i->piso=1; i->cant=0;strcpy(i->nombre,"Armadura de cuero");i->valor=1 ; break;
                    case 6:i->simbolo='&';i->tipo=0 ;i->piso=2; i->cant=0;strcpy(i->nombre,"Armadura de cota de malla"); i->valor=3; break;
                    case 7:i->simbolo='P';i->tipo=0 ;i->piso=4; i->cant=0;strcpy(i->nombre,"Armadura de plata");i->valor=5 ; break;
                    case 8:i->simbolo='/';i->tipo=1 ;i->piso=1; i->cant=0;strcpy(i->nombre,"Espada larga"); i->valor=3; break;
                    case 9:i->simbolo='X';i->tipo=1 ;i->piso=3; i->cant=0;strcpy(i->nombre,"Shuriken"); i->valor=5; break;
                }
            }
        
        }while(piso<i->piso);
    }

}

char obtenerSimboloItem(Mapa* mapa, int y, int x)
{
    int i, j;
    Item* it;
    for (i=0; i<3; i++)
    {
        for (j=0; j<3; j++)
        {
            if (mapa->salas[i][j].existe && mapa->salas[i][j].hayItem==1)
            {
                it=&mapa->salas[i][j].item;

                if ( it->x==x && it->y==y && it->activo)
                {
                    return it->simbolo;
                }
            }
        }
    }
    return '\0';
}

void agarrarItem(Mapa* mapa, Jugador* player, int f, int c)
{
    Item* i=&mapa->salas[f][c].item;
    int flag=0, j=0;

    printf("\nEncontraste %s", i->nombre);

    while(flag==0 && j<player->cantItems) //recorro el inventario para ver si ya agarre el mismo item
    {
        if(player->inventario[j].simbolo==i->simbolo) flag=1;
        j++;
    }

    if(flag==0) // si no lo agarre nunca lo agrego al inventario
    {
        if (player->cantItems<MAX_INV)
        {
            player->inventario[player->cantItems]=*i;
            player->inventario[player->cantItems].cant=1;
            player->cantItems++;
            i->activo=0;
        }
        else
        {
            printf("\nInventario lleno!");
        }
    }
    else //si ya lo agarre sumamos uno
    {
        player->inventario[j-1].cant++;
        i->activo=0;
    }

    if(i->simbolo=='Y') //si encontre el amuleto, ganamos
    {
        player->tieneAmuleto=1;
    }


    getch();
}

void equiparArmadura(Jugador* player, int indice)
{
    char  comando;
    int i;
    Item* it=&player->inventario[indice];
    Item aux;

    if(player->tieneArmadura==1)
    {
        aux=player->armadura;
        if(player->armadura.simbolo==it->simbolo)
        {
            printf("\nYa tenes equipada %s", player->armadura.nombre);
            getch();
        }
        else
        {
            printf("\nTenes equipada %s | Reemplazar por %s? [Y]:Si [N]:No", player->armadura.nombre, it->nombre);
            comando=getch();

            if(comando=='y' || comando=='Y')
            {
                player->armadura=*it;       //equipo la nueva armadura
                player->inventario[indice]=aux; //ponemos la otra en el inventario
            }
        }
    }
    else
    {
        printf("\nEquipaste %s", it->nombre);
        player->tieneArmadura=1;
        player->armadura=*it;

        for(i=indice ; i<player->cantItems-1; i++)
        {
            player->inventario[i]=player->inventario[i+1];
        }

        player->cantItems--;
        getch();
    }
}

void equiparArma(Jugador* player, int indice) //es exactamente la misma funcion qeu arriba, en un futuro puede hacerse una funcion equiparObjeto()
{
    char  comando;
    int i;
    Item* it=&player->inventario[indice];
    Item aux;

    if(player->tieneArma==1)
    {
        aux=player->arma;
        if(player->arma.simbolo==it->simbolo)
        {
            printf("\nYa tenes equipado %s", player->arma.nombre);
            getch();
        }
        else
        {
            printf("\nTenes equipado %s | Reemplazar por %s? [Y]:Si [N]:No", player->arma.nombre, it->nombre);
            comando=getch();

            if(comando=='y' || comando=='Y')
            {
                player->arma=*it;
                player->inventario[indice]=aux;
            }
        }
    }
    else
    {
        printf("\nEquipaste %s", it->nombre);
        player->tieneArma=1;
        player->arma=*it;

        for(i=indice ; i<player->cantItems-1; i++)
        {
            player->inventario[i]=player->inventario[i+1];
        }

        player->cantItems--;
        getch();
    }
}

void consumir(Jugador* player, Item* i,int indice)
{;
    int j;

    printf("\nUsaste %s. Presiona cualquier tecla para volver", i->nombre);
    i->cant--;
    if(i->cant==0)
    {
        for(j=indice ; j<player->cantItems-1; j++)
        {
            player->inventario[j]=player->inventario[j+1];
        }
        player->cantItems--;     
    }
    getch();
    
}

void usar(Jugador* player, int indice)
{
    Item* i=&player->inventario[indice];
    char* simbolo=&player->inventario[indice].simbolo;
    char comando;

    switch (*simbolo)
    {
        case 'H': 
            system("cls"); 
            printf("\n%s: restaura 25 HP | [Y]:Usar [N]:Atras",i->nombre); 
            comando=getch();
            if(comando=='Y' || comando=='y')
            {
                player->hp+=i->valor;
                if(player->hp>player->hpMax) player->hp=player->hpMax; // para que no se pase de la vida maxima
                consumir(player,i,indice); 
            }
            break;

        case 'E': 
            system("cls"); 
            printf("\n%s: otorga 20 EXP | [Y]:Usar [N]:Atras",i->nombre); 
            comando=getch();
            if(comando=='Y' || comando=='y')
            {
                player->exp+=i->valor;
                if(player->exp>=player->nivel*100) subirNivel(player);
                consumir(player,i,indice); 
            }
            break;

        case 'F':
            system("cls"); 
            printf("\n%s: incrementa Fuerza en 2 | [Y]:Usar [N]:Atras",i->nombre); 
            comando=getch();
            if(comando=='Y' || comando=='y')
            {
                player->fuerza+=i->valor;
                consumir(player,i,indice); 
            }
            break;
        case 'V': 
            system("cls"); 
            printf("\n%s: ???? | [Y]:Usar [N]:Atras",i->nombre); 
            comando=getch();
            if(comando=='Y' || comando=='y')
            {
                player->hp-=i->valor;
                consumir(player,i,indice); 
            }
            break;
    }

}

void accion(Jugador* player, char comando)
{
    Item* it;
    int indice, tipo;

    indice=comando-'1';  // como recibo el indice+1 como char le resto el caracter '1' que es igual a 49

    if (indice>=0 && indice<player->cantItems)
    {
        it=&player->inventario[indice];
        tipo=it->tipo;

        switch (tipo)
        {
            case 0: equiparArmadura(player,indice); break;
            case 1: equiparArma(player,indice); break;
            case 2: usar(player,indice); break;
        }
    }
}

void mostrarInventario(Jugador* player)
{
    char comando='a';
    int i;

    while(comando!='I' && comando!='i')
    {
        system("cls");
        if(player->cantItems==0) printf("\nInventario vacio");
        else
        {
            for(i=0; i<player->cantItems; i++)
            {
                printf("\n%d) %s: %d", i+1, player->inventario[i].nombre,player->inventario[i].cant);
            }
        }
        printf("\n[Presione I para volver]");
        comando=getch();

        accion(player,comando);
    }
}
