#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <conio.h>
#include "PruebasRogue.h"

char obtenerSimboloEnemigo(Mapa* mapa, int y, int x)
{
    int i, j;
    for (i=0; i<3; i++)
    {
        for (j=0; j<3; j++)
        {
            if (mapa->salas[i][j].existe && mapa->salas[i][j].enemigo==1)
            {
                Enemigo* e=&mapa->salas[i][j].mob;
                if (e->activo && e->x==x && e->y==y)
                {
                    return e->simbolo;
                }
            }
        }
    }
    return '\0';
}

void colocarEnemigo(Mapa* mapa, int f, int c, int piso)
{
    Enemigo* e;
    int tipo;
    if (mapa->salas[f][c].visitada==0)
    {
        revelarSala(mapa, f, c);
        mapa->salas[f][c].visitada=1;

        do
        {    
            e=&mapa->salas[f][c].mob; //apuntamos a este monstruo para no escribir tanto
            mapa->salas[f][c].enemigo= 1;

            //lo ponemos en un lugar aleatorio DENTRO de esta sala | +1 para que no este dentro de una pared
            e->x=mapa->salas[f][c].x + 1 + (rand() % (mapa->salas[f][c].ancho-2));
            e->y=mapa->salas[f][c].y + 1 + (rand() % (mapa->salas[f][c].alto-2));
            e->activo=1;

            tipo=rand() % 7;
            switch (tipo)
            {
                case 0: e->simbolo='G'; e->hp=20; e->piso=2 ;e->xp=30 ;e->damage=10; strcpy(e->nombre,"Gigante"); break;
                case 1: e->simbolo='M'; e->hp=5;  e->piso=0 ;e->xp=14 ;e->damage=5; strcpy(e->nombre,"Murcielago"); break;
                case 2: e->simbolo='C'; e->hp=14; e->piso=1 ;e->xp=28 ;e->damage=8; strcpy(e->nombre,"Centauro"); break;
                case 3: e->simbolo='Z'; e->hp=10; e->piso=0 ;e->xp=20 ;e->damage=6; strcpy(e->nombre,"Zombie"); break;
                case 4: e->simbolo='D'; e->hp=50; e->piso=4 ;e->xp=50 ;e->damage=20; strcpy(e->nombre,"Dragon"); break;
                case 5: e->simbolo='S'; e->hp=8; e->piso=1 ;e->xp=18 ;e->damage=7; strcpy(e->nombre,"Serpiente"); break;
                case 6: e->simbolo='T'; e->hp=30; e->piso=3 ;e->xp=40 ;e->damage=14; strcpy(e->nombre,"Troll"); break;
            }
        }while(piso<e->piso);
        
    }
}

void moverEnemigo(Mapa* mapa, Jugador* player, int f, int c)
{
    Enemigo* enem=&mapa->salas[f][c].mob;
    if (!enem->activo) return; // Solo si está vivo
    char destino;

    int sigX=enem->x;
    int sigY=enem->y;

    if (enem->x < player->x) sigX++;
    else if (enem->x > player->x) sigX--;

    if (enem->y < player->y) sigY++;
    else if (enem->y > player->y) sigY--;

    // verificamos el terreno de destino antes de moverlo
    destino=mapa->grilla[sigY][sigX];

    if (destino=='.' || destino=='#' || destino=='+')
    {
        if (sigX==player->x && sigY==player->y)
        {

        }
        else
        {
            enem->x=sigX;
            enem->y=sigY;
        }
    }
}

void subirNivel(Jugador* player)
{
    printf("\nSubiste de nivel!");
    player->exp=0;
    player->nivel++;
    player->fuerza+=2;
    player->hpMax+=20;
}

void combate(Mapa* mapa, Jugador* player, int f, int c, int pisoActual, int pisos)
{
    int hit;
    Enemigo* enem=&mapa->salas[f][c].mob;
    Item* yendor;

    if(player->tieneArma==1) hit=(rand()%player->fuerza+player->arma.valor)+1;
    else hit=(rand()%player->fuerza);
    
    if(hit==0)
    {
        printf("\nFallaste el golpe contra %s", enem->nombre);

        if(player->tieneArmadura==1) player->hp-= (enem->damage) - (player->armadura.valor); // la armadura ofrece resistencia
        else player->hp-=enem->damage;   
        printf("\n%s te golpea! Pierdes %d HP", enem->nombre, enem->damage);

        getch();
    }
    else
    {
        enem->hp-=hit;
        if(enem->hp<=0)
        {
            printf("\n%s derrotado", enem->nombre);
            enem->activo=0;
            player->exp+=enem->xp;
            if(player->exp>=player->nivel*100) subirNivel(player);
            mapa->enemigosVivos--;
            getch();

            if (pisoActual==pisos-1  && mapa->enemigosVivos==0) //si mate al ultimo enemigo del ultimo piso dropea el amuleto
            {
                yendor=&mapa->salas[f][c].item;
                yendor->x=enem->x;
                yendor->y=enem->y;
                yendor->activo=1;
                yendor->simbolo='Y';
                yendor->valor=0;
                strcpy(yendor->nombre,"Amuleto de Yendor");
                
                mapa->salas[f][c].hayItem=1;
                
                printf("\n%s ha dejado caer algo, tiene un brillo unico", enem->nombre);
                getch();
            }

        }
        else //cada vez que lo golpeamos , si no lo matamos nos  devuelve el golpe
        {
            printf("\nGolpeaste al %s! %dHP restante", enem->nombre, enem->hp);

            if(player->tieneArmadura==1) player->hp-= (enem->damage) - (player->armadura.valor);
            else player->hp-=enem->damage;   

            printf("\n%s te golpea! Pierdes %d HP", enem->nombre, enem->damage);
            getch();
        }
    }
}
