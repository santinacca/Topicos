#ifndef ESTRUCTURAS_H_INCLUDED
#define ESTRUCTURAS_H_INCLUDED

//dimension del mapa (grilla de 3x3)
#define FIL 34
#define COL 64
#define FIL_SALAS 3
#define COL_SALAS 3

//dimension de habitaciones  
#define ALTO_MAX_SALA 10
#define ANCHO_MAX_SALA 20

//probabilidad de sala
#define PROB_SALA 70

//macros
#define MIN(a,b) ((a) < (b) ? (a) : (b))
#define MAX(a,b) ((a) > (b) ? (a) : (b))

//inventario
#define MAX_INV 10

typedef struct
{
    int x, y;
    int hp;
    int damage;
    int xp;
    char simbolo;
    int activo;  // 1=vivo 0=muerto
    char nombre[20];
    int piso; // apartir de que piso spawnea el enemigo
}Enemigo;

typedef struct
{
    int x, y;
    char nombre[30];
    char simbolo;
    int valor;
    int activo;
    int piso; // apartir de que piso spawnea el item
    int tipo; // 0=armadura , 1=arma, 2=consumible
    int cant; // cantidad en inventario
}Item;


typedef struct
{
    int x,y;         // posicion en la grilla
    int alto, ancho; // dimension de la sala
    int existe;     // cada sala tiene una probabilidad de aparecer
    int visitada;  // para spawnear enemigos una sola vez
    int enemigo;    // para ver si tiene un enemigo dentro
    int hayItem;
    Enemigo mob;
    Item item;
}Sala;

typedef struct
{
    char** grilla; //aca uso memoria dinamica
    int** visible;
    Sala salas[FIL_SALAS][COL_SALAS];
    int filas, columnas;
    int enemigosVivos;
}Mapa;

typedef struct
{
    int x, y;
    int hp, hpMax;
    int nivel;
    int exp;
    int fuerza;
    Item inventario[MAX_INV];
    int cantItems;
    int tieneArma;
    Item arma;
    int tieneArmadura;
    Item armadura;
    int tieneAmuleto;
} Jugador;





#endif // ESTRUCTURAS_H_INCLUDED
