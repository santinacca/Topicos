#ifndef PRUEBASROGUE_H_INCLUDED
#define PRUEBASROGUE_H_INCLUDED
#include "Estructuras.h"

//creacion de mapa
void mostrarMapa(Mapa* mapa, Jugador player, int piso);
void generarMapa(Mapa* mapa);
void generarSala(Mapa* mapa, int f, int c);
void generarPasilloDerecha(Mapa* mapa, int f1, int c1, int f2, int c2);
void generarPasilloAbajo(Mapa* mapa, int f1, int c1, int f2, int c2);
Mapa* inicializarMapa(int f, int c);
void liberarMapa(Mapa* mapa);
void revelarSala(Mapa* mapa, int f, int c);
void crear(Mapa** mapa, int pisos);
void colocarEscalera(Mapa* mapa);
void colocarEscaleraArriba(Mapa* mapa);

//juego
void inicializarJugador(Jugador* j, int x, int y);
void juego(Mapa** mapa, int pisos);
void terminarjuego(Mapa** vecMap, int pisos);
Jugador colocarJugador(Mapa* mapa);
void siguienteNivel(Mapa* mapa, Jugador* player, char escalera);
char obtenerSimboloItem(Mapa* mapa, int y, int x);
void colocarItem(Mapa* mapa, int f, int c, int piso);
void agarrarItem(Mapa* mapa, Jugador* player, int f, int c);
int mostrarMenu(int* pisos);

//inventario
void mostrarInventario(Jugador* player);
void accion(Jugador* player, char comando);
void equiparArmadura(Jugador* player, int indice);
void equiparArma(Jugador* player, int indice);
void usar(Jugador* player, int indice);
void consumir(Jugador* player, Item* i,int indice);

//enemigos
void colocarEnemigo(Mapa* mapa, int f, int c, int piso);
char obtenerSimboloEnemigo(Mapa* mapa, int y, int x);
void moverEnemigo(Mapa* mapa, Jugador* player, int f, int c);
void combate(Mapa* mapa, Jugador* player, int f, int c, int pisoActual, int pisos);
void subirNivel(Jugador* player);

#endif // PRUEBASROGUE_H_INCLUDED
