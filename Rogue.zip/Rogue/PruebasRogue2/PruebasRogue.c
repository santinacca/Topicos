#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include "PruebasRogue.h"

void mostrarMapa(Mapa* mapa, Jugador player, int piso)
{
    int i, j;
    char simbEnemigo;
    char simbItem;
    system("cls");

    for (i=0; i<mapa->filas; i++)
    {
        for (j=0; j < mapa->columnas; j++)
        {
            // si el jugador esta ahi imprimilo
            if (i==player.y && j==player.x)
            {
                printf("@");
            }
            else {
                //buscamos si hay un enemigo en esta celda
                simbEnemigo=obtenerSimboloEnemigo(mapa, i, j);
                simbItem=obtenerSimboloItem(mapa,i,j);

                if (simbItem!='\0' && mapa->visible[i][j]==1)
                {
                    printf("%c",simbItem);
                }
                //si hay un enemigo Y la celda es visible para el jugador
                else if (simbEnemigo!='\0' && mapa->visible[i][j]==1)
                {
                    printf("%c",simbEnemigo);
                }
                //dibujamos el mapa normal
                else if (mapa->visible[i][j]==1)
                {
                    printf("%c",mapa->grilla[i][j]);
                }
                else {
                    printf(" ");
                }
            }
        }
        printf("\n");
    }

    printf("\nNivel: %d | Exp: %d/%d | HP: %d/%d | Fuerza: %d | Piso: %d | Enemigos vivos: %d" ,
        player.nivel, player.exp, player.nivel*100  ,player.hp, player.hpMax, player.fuerza, piso+1, mapa->enemigosVivos);
    if(player.tieneArmadura==1) printf("\nArmadura: %s ", player.armadura.nombre);
    if(player.tieneArma==1) printf("| Arma: %s", player.arma.nombre);
}

int mostrarMenu(int* pisos)
{
    int opcion;
    system("cls");
    printf("==========================================\n");
    printf("                  Rogue                   \n");
    printf("==========================================\n");
    printf("\n 1. Iniciar Partida");
    printf("\n 2. Instrucciones");
    printf("\n 3. Salir");
    printf("\n\n Seleccione una opcion: ");
    scanf("%d", &opcion);

    if (opcion==1)
    {
        printf("\n Cantidad de pisos de la mazmorra (Recomendado 5-10): ");
        scanf("%d", pisos);

        printf("\n Generando mundo... Presiona una tecla.");
        getch();
        return 1; //el juego comienza
    }

    if (opcion==2)
    {
        system("cls");
        printf("--- INSTRUCCIONES ---\n");
        printf("- Movimiento: W: Arriba | S: Abajo | A: Izquierda | D: Derecha.\n");
        printf("- Para agarrar un item intenta pararte sobre el y usa el inventario con 'I'.\n");
        printf("- Mata a TODOS los enemigos para bajar de piso.\n");
        printf("- Encuentra el Amuleto de Yendor.\n");
        printf("\nPresiona cualquier tecla para volver.");
        getch();
        return mostrarMenu(pisos); // volver al menu
    }

    return 0;
}
