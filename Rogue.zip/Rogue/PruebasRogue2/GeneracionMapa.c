#include <time.h>
#include <stdlib.h>
#include "PruebasRogue.h"

Mapa* inicializarMapa(int f, int c)
{
    int i, j;
    //reservo memoria para la estructura principal
    Mapa* nuevoMapa=(Mapa*)malloc(sizeof(Mapa));

    nuevoMapa->filas=f;
    nuevoMapa->columnas=c;

    //reservo memoria para las filas (punteros a char) | lo mismo para la matriz visible con int
    nuevoMapa->grilla=malloc(f*sizeof(char*));
    nuevoMapa->visible=malloc(f*sizeof(int*));

    //para cada fila, reservo memoria para los datos (los char reales)
    for (i=0; i<f; i++)
    {
        nuevoMapa->grilla[i]=malloc(c*sizeof(char));
        nuevoMapa->visible[i]=malloc(c*sizeof(int));

        //llenar la matriz de espacios para diferenciar bien las paredes
        for (j=0; j<c; j++)
        {
            nuevoMapa->grilla[i][j]=' ';
            nuevoMapa->visible[i][j]=1;
        }
    }
    nuevoMapa->enemigosVivos=0;
    return nuevoMapa;
}

void liberarMapa(Mapa* mapa)
{
    int i;

    for (i=0; i<mapa->filas; i++)
    {
        free(mapa->grilla[i]);
        free(mapa->visible[i]);
    }
    free(mapa->grilla);
    free(mapa->visible);
    free(mapa);
}

void generarSala(Mapa* mapa,int f, int c)
{
    int i,j;
    Sala* sala= &mapa->salas[f][c]; //creo un puntero a esa sala para escribir menos

    for(i=sala->y ; i<sala->y+sala->alto ; i++)
    {
        for(j=sala->x; j<sala->x+sala->ancho; j++) //me paro en la posicion (x,y) y genero la habitacion
        {

            if (i==sala->y || i==sala->y+sala->alto-1)
            {
                mapa->grilla[i][j]='-';
            }
            else if (j==sala->x || j==sala->x+sala->ancho-1)
            {
                mapa->grilla[i][j]='|';
            }
            else
            {
                mapa->grilla[i][j]='.';
            }
        }
    }
    sala->visitada=0;
    sala->enemigo=0;
}

void dibujarCeldaPasillo(Mapa* mapa, int y, int x)
{
    char caracter=mapa->grilla[y][x];

    if (caracter=='-' || caracter=='|')
    {
        // ponemos puerta si NO hay otra puerta al lado
        if (mapa->grilla[y][x-1]!='+' && mapa->grilla[y][x+1]!='+' && mapa->grilla[y-1][x]!='+' && mapa->grilla[y+1][x]!='+')
        {
            mapa->grilla[y][x]='+';
        }

    }
    else if (caracter==' ')
    {
        mapa->grilla[y][x]='#';
    }
}

void generarPasilloAbajo(Mapa* mapa, int f1, int c1, int f2, int c2)
{
    int i, j;

    Sala* s1=&mapa->salas[f1][c1]; //sala anterior
    Sala* s2=&mapa->salas[f2][c2]; //sala actual

    //ubicamos el centro de cada sala
    int cx1=s1->x+s1->ancho/2;
    int cy1=s1->y+s1->alto/2;
    int cx2=s2->x+s2->ancho/2;
    int cy2=s2->y+s2->alto/2;

    //busco el punto medio entre las dos salas, en este caso multiplico por f2 ya que al recorrer de arriba hacia abajo siempre sera el mas alto
    int puntoMedioY=f2*ALTO_MAX_SALA-1;

    //arranco desde el centro (poniendo una puerta) y luego escribo "#" hasta el punto medio hacia abajo
    for (i=cy1; i<=puntoMedioY; i++)
    {
        dibujarCeldaPasillo(mapa,i,cx1);
    }

    //busco el centro que este mas a la izquierda, para generar el pasillo de izq a derecha, y voy hasta la coordenada "x" del centro de la sala de abajo
    for (j=MIN(cx1,cx2); j<=MAX(cx1,cx2); j++)
    {
        dibujarCeldaPasillo(mapa,puntoMedioY,j);
    }

    //ahora bajo denuevo hasta la coordenada "y" del centro de la sala de abajo generando el pasillo, y al final coloco la puerta.
    for (i=puntoMedioY; i<=cy2; i++)
    {
        dibujarCeldaPasillo(mapa,i,cx2);
    }
}

void generarPasilloDerecha(Mapa* mapa, int f1, int c1, int f2, int c2)
{
    int i, j;

    Sala* s1=&mapa->salas[f1][c1];
    Sala* s2=&mapa->salas[f2][c2];

    int cx1=s1->x+s1->ancho/2;
    int cy1=s1->y+s1->alto/2;
    int cx2=s2->x+s2->ancho/2;
    int cy2=s2->y+s2->alto/2;

    int puntoMedioX=c2*ANCHO_MAX_SALA-1;

    //funciona igual que la otra funcion, solo que primero voy hacia la derecha, luego abajo , y luego a la dercha otra vez, formando la Z
    for (j=cx1; j<=puntoMedioX; j++)
    {
        dibujarCeldaPasillo(mapa,cy1,j);
    }

    for (i=MIN(cy1,cy2); i<=MAX(cy1,cy2); i++)
    {
        dibujarCeldaPasillo(mapa,i,puntoMedioX);
    }

    for (j=puntoMedioX; j<=cx2; j++)
    {
        dibujarCeldaPasillo(mapa,cy2,j);
    }
}

void colocarEscalera(Mapa* mapa)
{
    int i, j, flag=0, medioX, medioY;

    //busco una sala random
    while(flag==0)
    {
        i=rand()%3;
        j=rand()%3;
        if(mapa->salas[i][j].existe==1)
        {
            flag=1;
        }
    }

    //ubico el centro y coloco una escalera para bajar
    medioX=mapa->salas[i][j].x + mapa->salas[i][j].ancho/2;
    medioY=mapa->salas[i][j].y + mapa->salas[i][j].alto/2;

    mapa->grilla[medioY][medioX]='>';
}

void colocarEscaleraArriba(Mapa* mapa)
{
     int i, j, flag=0, medioX, medioY;

    //de igual manera , busco una sala existente, y coloco la escalera en el medio
    while(flag==0)
    {
        i=rand()%3;
        j=rand()%3;

        if(mapa->salas[i][j].existe==1)
        {
            medioX=mapa->salas[i][j].x + mapa->salas[i][j].ancho/2;
            medioY=mapa->salas[i][j].y + mapa->salas[i][j].alto/2;

            if(mapa->grilla[medioY][medioX] != '>')
            {
                flag=1;
            }
        }
    }

    mapa->grilla[medioY][medioX]='<';
}

void generarMapa(Mapa* mapa)
{
    int i, j;
    int baseX, baseY;
    int fAnterior=-1, cAnterior=-1; // indicadores de la sala anterior en la matriz 3x3 de salas

    for(i=0; i<FIL_SALAS; i++) //recorro la grilla de 3x3 y si la sala se genera le cargo los datos de ubicacion
    {
        for(j=0; j<COL_SALAS; j++)
        {
            if((rand()%100) < PROB_SALA)
            {
                mapa->salas[i][j].existe=1;

                baseX=j*ANCHO_MAX_SALA; // la base hace referencia a la primera posicion de cada parte de la grilla 3x3 | es decir la esquina superior izquierda
                baseY=i*ALTO_MAX_SALA;

                mapa->salas[i][j].alto=(rand()%6)+4; // entre 4 y 9
                mapa->salas[i][j].ancho=(rand()%12)+6; // entre 6 y 17

                mapa->salas[i][j].x=(rand() % (ANCHO_MAX_SALA-mapa->salas[i][j].ancho))+baseX; // posicion aleatoria para generarla partiendo de la base
                mapa->salas[i][j].y=(rand() % (ALTO_MAX_SALA-mapa->salas[i][j].alto))+baseY;

                mapa->enemigosVivos++;

                generarSala(mapa,i,j);
            }
            else
            {
                mapa->salas[i][j].existe=0;
            }
        }
    }

    for (i=0; i<FIL_SALAS; i++)
    {
        for (j=0; j<COL_SALAS; j++)
        {
            if (mapa->salas[i][j].existe==1)
            {
                //si ya teniamos una sala registrada previamente, la conectamos con esta
                if (fAnterior!=-1)
                {
                    if (fAnterior==i)
                    {
                        //estan en la misma fila -> Pasillo Horizontal normal
                        generarPasilloDerecha(mapa,fAnterior,cAnterior,i,j);
                    }
                    else
                    {
                        //estan en distintas filas -> Pasillo en "Z" Vertical
                        generarPasilloAbajo(mapa,fAnterior,cAnterior,i,j);
                    }
                }

                //actualizamos la sala "anterior" para que la próxima descubierta se conecte a esta | la primera vuelta siempre entra aca
                fAnterior=i;
                cAnterior=j;
            }
        }
    }
}

void crear(Mapa** mapa, int pisos)
{
    int i;

    for (i=0; i<pisos; i++)
    {
        mapa[i]=inicializarMapa(FIL, COL);
        generarMapa(mapa[i]);
        if(i<pisos-1) //si no estoy en el ultimo piso
        {
            colocarEscalera(mapa[i]);
        }

        if(i>0) //si no estoy en el primer piso
        {
            colocarEscaleraArriba(mapa[i]);
        }
    }
}
