#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include "PruebasRogue.h"
int main()
{
    int arrancar, pisos;
    srand(time(NULL));

    arrancar=mostrarMenu(&pisos);

    if(arrancar==1)
    {

        Mapa** vecMap=(Mapa**)malloc(pisos*sizeof(Mapa*));
        crear(vecMap,pisos);

        juego(vecMap,pisos);

        terminarjuego(vecMap,pisos);

    }

    return 0;
}


